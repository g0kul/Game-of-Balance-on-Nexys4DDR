/*
 *timing.c: simple starter application for lab 1A and 1B
 *
 */

#include <stdio.h>		// Used for printf()
#include "xparameters.h"	// Contains hardware addresses and bit masks
#include "xil_cache.h"		// Cache Drivers
#include "xintc.h"		// Interrupt Drivers
#include "xtmrctr.h"		// Timer Drivers
#include "xtmrctr_l.h" 		// Low-level timer drivers
#include "xil_printf.h" 	// Used for xil_printf()
//#include "extra.h" 		// Provides a source of bus contention
#include "xgpio.h" 		// LED driver, used for General purpose I/i
#include "xspi.h"
#include "xspi_l.h"
#include "lcd.h"
#include "lcd_test.h"

#define DCOERCE40(x_) ((x_+1) % 40)? (((x_ / 40) * 40)-1) : (x_)
#define UCOERCE40(x_) ((x_+1) % 40)? ((((x_ / 40) + 1) * 40)-1) : (x_)

volatile int timerTrigger = 0;
int cx= 124, cy= 314;
int mx = 124, my= 314;
int vol_count = 0;
int inact_flag = 0;
int mute_flag = 0;

void TimerCounterHandler(void *CallBackRef, u8 TmrCtrNumber)
{
	timerTrigger = 100;
}

int lcd_spi_init()
{
	static XIntc intc;
	static XTmrCtr axiTimer;
	static XGpio dc;
	static XSpi spi;

	int i, j;

	XSpi_Config *spiConfig;	/* Pointer to Configuration data */

	u32 status;
	u32 controlReg;

	int sec = 0;
	int secTmp;
	char secStr[4];

	//---------
	int vol = 0;
	char volStr[3];
	//---------

	//Xil_ICacheEnable();
	//Xil_DCacheEnable();
	print("---Entering main (CK)---\n\r");

#if 0
	status = XTmrCtr_Initialize(&axiTimer, XPAR_AXI_TIMER_0_DEVICE_ID);
	if (status != XST_SUCCESS) {
		xil_printf("Initialize timer fail!\n");
		return XST_FAILURE;
	}

	status = XIntc_Initialize(&intc, XPAR_INTC_0_DEVICE_ID);
	if (status != XST_SUCCESS) {
		xil_printf("Initialize interrupt controller fail!\n");
		return XST_FAILURE;
	}

	status = XIntc_Connect(&intc,
				XPAR_MICROBLAZE_0_AXI_INTC_AXI_TIMER_0_INTERRUPT_INTR,
				(XInterruptHandler)XTmrCtr_InterruptHandler,
				(void *)&axiTimer);
	if (status != XST_SUCCESS) {
		xil_printf("Connect IHR fail!\n");
		return XST_FAILURE;
	}

	status = XIntc_Start(&intc, XIN_REAL_MODE);
	if (status != XST_SUCCESS) {
		xil_printf("Start interrupt controller fail!\n");
		return XST_FAILURE;
	}

	// Enable interrupt
	XIntc_Enable(&intc, XPAR_MICROBLAZE_0_AXI_INTC_AXI_TIMER_0_INTERRUPT_INTR);
	microblaze_enable_interrupts();

	/*
	 * Setup the handler for the timer counter that will be called from the
	 * interrupt context when the timer expires, specify a pointer to the
	 * timer counter driver instance as the callback reference so the handler
	 * is able to access the instance data
	 */
	XTmrCtr_SetHandler(&axiTimer, TimerCounterHandler, &axiTimer);

	/*
	 * Enable the interrupt of the timer counter so interrupts will occur
	 * and use auto reload mode such that the timer counter will reload
	 * itself automatically and continue repeatedly, without this option
	 * it would expire once only
	 */
	XTmrCtr_SetOptions(&axiTimer, 0,
				XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);

	/*
	 * Set a reset value for the timer counter such that it will expire
	 * eariler than letting it roll over from 0, the reset value is loaded
	 * into the timer counter when it is started
	 */
	XTmrCtr_SetResetValue(&axiTimer, 0, 0xFFFF0000);

	/*
	 * Start the timer counter such that it's incrementing by default,
	 * then wait for it to timeout a number of times
	 */
	XTmrCtr_Start(&axiTimer, 0);
	xil_printf("Timer start!\n");

#endif

	/*
	 * Initialize the GPIO driver so that it's ready to use,
	 * specify the device ID that is generated in xparameters.h
	 */
	status = XGpio_Initialize(&dc, XPAR_SPI_DC_DEVICE_ID);
	if (status != XST_SUCCESS)  {
		xil_printf("Initialize GPIO dc fail!\n");
		return XST_FAILURE;
	}

	/*
	 * Set the direction for all signals to be outputs
	 */
	XGpio_SetDataDirection(&dc, 1, 0x0);


	/*
	 * Initialize the SPI driver so that it is  ready to use.
	 */
	spiConfig = XSpi_LookupConfig(XPAR_SPI_DEVICE_ID);
	if (spiConfig == NULL) {
		xil_printf("Can't find spi device!\n");
		return XST_DEVICE_NOT_FOUND;
	}

	status = XSpi_CfgInitialize(&spi, spiConfig, spiConfig->BaseAddress);
	if (status != XST_SUCCESS) {
		xil_printf("Initialize spi fail!\n");
		return XST_FAILURE;
	}

	/*
	 * Reset the SPI device to leave it in a known good state.
	 */
	XSpi_Reset(&spi);

	/*
	 * Setup the control register to enable master mode
	 */
	controlReg = XSpi_GetControlReg(&spi);
	XSpi_SetControlReg(&spi,
			(controlReg | XSP_CR_ENABLE_MASK | XSP_CR_MASTER_MODE_MASK) &
			(~XSP_CR_TRANS_INHIBIT_MASK));

	// Select 1st slave device
	XSpi_SetSlaveSelectReg(&spi, ~0x01);

	initLCD();

	clrScr();

	drawBackground(0,0,DISP_X_SIZE,DISP_Y_SIZE);

	//Number to ASCII characters
	//vol = 42;
	//volStr[0] = (vol / 10) + 48;
	//volStr[1] = (vol % 10) + 48;
	//volStr[2] = '\0';

	//setFont(BigFont);
	//setColor(0, 255, 0);
	//setColorBg(255, 0, 0);
	//lcdPrint("Volume", 45, 85);

/*
	setFont(BigFont);
	setColor(0, 0, 255);
	setColorBg(0, 255, 0);
	lcdPrint("World 22", 40, 80);

	setFont(SevenSegNumFont);
	setColor(238, 64, 0);
	setColorBg(0, 50, 100);
	*/

#if 0
	while (1) {
		if (timerTrigger > 0) {
			secTmp = sec++ % 1000;
			secStr[0] = secTmp / 100 + 48;
			secTmp -= (secStr[0] - 48) * 100;
			secStr[1] = secTmp / 10 + 48;
			secTmp -= (secStr[1] - 48) * 10;
			secStr[2] = secTmp + 48;
			secStr[3] = '\0';

			lcdPrint(secStr, 70, 190);

			timerTrigger = 0;
		}
	}
#endif

	xil_printf("End\n");
	return 0;
}

int drawBackground(int x1, int y1, int x2, int y2)
{
	int i, j;

	//Limit ranges
	x1 = (x1 > DISP_X_SIZE)? DISP_X_SIZE : x1;
	y1 = (x1 > DISP_Y_SIZE)? DISP_Y_SIZE : y1;
	x2 = (x2 > DISP_X_SIZE)? DISP_X_SIZE : x2;
	y2 = (y2 > DISP_Y_SIZE)? DISP_Y_SIZE : y2;

	x1 = DCOERCE40(x1);	//coerce to range
	y1 = DCOERCE40(y1);	//coerce to range
	x2 = UCOERCE40(x2);	//coerce to range
	y2 = UCOERCE40(y2);	//coerce to range

    if (x1 > x2)
        swap(int, x1, x2);

    if (y1 > y2)
        swap(int, y1, y2);

	//Fill Background
	setColor(0, 0, 255);
	fillRect(x1,y1,x2,y2);

	//Fill Boxes
	setColor(0, 255, 255);
	for (i = x1; i<x2; i = i + 40)
		for (j=y1; j<y2; j = j+40)
			fillRect(i+5, j+5, i+35, j+35);

	return 0;
}

int drawBackground1(int x1, int y1, int x2, int y2)
{


	//Limit ranges
	x1 = (x1 > DISP_X_SIZE)? DISP_X_SIZE : x1;
	y1 = (x1 > DISP_Y_SIZE)? DISP_Y_SIZE : y1;
	x2 = (x2 > DISP_X_SIZE)? DISP_X_SIZE : x2;
	y2 = (y2 > DISP_Y_SIZE)? DISP_Y_SIZE : y2;

	x1 = DCOERCE40(x1);	//coerce to range
	y1 = DCOERCE40(y1);	//coerce to range
	//x2 = UCOERCE40(x2);	//coerce to range
	//y2 = UCOERCE40(y2);	//coerce to range

    if (x1 > x2)
        swap(int, x1, x2);

    if (y1 > y2)
        swap(int, y1, y2);

	//Fill Background
	setColor(0, 0, 255);
	fillRect(x1,y1,x2,y2);

	y2 = (y2 > (y1 + 35))? y1+35 : y2;

	if(y2 > (y1 + 5))
	{
		//Fill Boxes
		setColor(0, 255, 255);
		fillRect(x1+5, y1+5, x2, y2);
	}


	return 0;
}

void volumecontrol(int sig)
{

	setColor(255,0,0);// Red color for the increasing volume
	if(inact_flag == 1)
			{
			fillRect(cx+30,cy,mx,my);
			inact_flag = 0;
			}
	if(sig == 0 && vol_count < 63 && mute_flag == 0) //up vol
	{
		fillRect(cx,cy,cx+30,cy-2);
		cy-=2;
		vol_count++;

	}
	else if(sig == 1 && vol_count > 0 && mute_flag == 0)//down vol
	{
		drawBackground1(cx,cy,cx+30,cy+2);
		cy+=2;
		vol_count--;
	}
	else if(sig == 2 && mute_flag == 0)//mute
	{
		drawBackground(cx,cy,mx,my);
		setColor(255,0,0);
		fillRect(mx+30,my+2,mx,my);
		mute_flag = 1 ;
	}
	else if(sig == 3)//unmute
	{
		setColor(255,0,0);
		fillRect(cx+30,cy,mx,my);
		if(mute_flag == 1) //Change mute flag to zero when unmuting
		{
			mute_flag = 0;
		}
	}

}
void clr_inact(void) //clear the screen if inactive ~2 seconds
{
	drawBackground(45,5,155,35);
	drawBackground(cx+30,cy,mx,my);
	inact_flag = 1;
}



