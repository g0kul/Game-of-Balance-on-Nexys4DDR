int lcd_spi_init();
int drawBackground(int x1, int y1, int x2, int y2);
int drawBackground1(int x1, int y1, int x2, int y2);
void volumecontrol(int sig);
void clr_inact(void);
